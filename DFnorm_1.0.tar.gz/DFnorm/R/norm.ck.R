norm.ck <-
function(acc, mcsum, inc.thres)
{if (missing(inc.thres)) {inc.thres=dim(acc)[[2]]/3}
 ccsum=colSums(acc)
 cc=round(as.matrix(acc)%*%diag(as.vector(mcsum/ccsum)))
 cc=as.data.frame(cc)
 names(cc)=names(acc)
 
 ccc=rowSums(cc)/dim(cc)[[2]]
 
 ccc=apply(cc, 1, median) 
 #raw=data.frame(cc, att)
 # see how sequencing depth affects correlation in normal samples
 #csum=colSums(raw)

 all.corc=apply(as.matrix(cc), 2, cf.fun, c.t=ccc, inc=ccc>inc.thres)
 sum.adj=cc*all.corc
 n.cor=rowSums(all.corc)/dim(all.corc)[[2]]
 
 ncc=cc
 adj.c=rep(NA, dim(cc)[[2]])
 
 for(i in 1:length(adj.c))
 {adj.c[i]=sum(cc[all.corc[,i],i])
  ncc[,i]=cc[,i]*sum(ccc[all.corc[,i]])/adj.c[i]
 }
 
 ncc0=round(ncc)
 return(ncc0)
}
