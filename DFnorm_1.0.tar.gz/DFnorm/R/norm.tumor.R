norm.tumor <-
function(att, tcor, ev.thres, kcut, inc.thres)
{if (missing(inc.thres)) {inc.thres=dim(att)[[2]]/3}
 selec.tumor=main.subtype(tcor, ev.thres, kcut)
 t.row=which(names(tcor)%in%selec.tumor)
 tt=round(att[,which(names(att)%in%selec.tumor)])
 ttt=rowSums(tt)/dim(tt)[[2]]
 
 all.tcor=apply(as.matrix(att), 2, cf.fun, c.t=ttt, inc=ttt>inc.thres)
 t.cor=rowSums(all.tcor)/dim(all.tcor)[[2]]
 adj.t=rep(NA, dim(att)[[2]])
 ntt=att
 adj.t=rep(NA, dim(att)[[2]])
 
 for(i in 1:length(adj.t))
 {#print(table(all.tcor[,i]))
   adj.t[i]=sum(att[all.tcor[,i],i])
   ntt[,i]=att[,i]*sum(ttt[all.tcor[,i]])/adj.t[i]
 }
 ntt0=ntt
 return(ntt0)
}
