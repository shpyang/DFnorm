DFnorm <-
function (raw0, TNstatus, cor, kcut, ev.thres, both.tumor, inc.thres)
{ print("If one group is tumor and another group is normal, then please make sure tumors are coded as 1 or TRUE, normals are coded as 0 or FALSE.")
  if (missing(inc.thres)) {inc.thres=dim(raw0)[[2]]/5}
  tn=TNstatus 
  if (missing (cor)) 
  {print("Generating Spearman correlation matrix, it might take a while.")
  cor=rcorr(as.matrix(raw0), type="spearman")[[1]]}
  tcor=cor[tn==1,tn==1]
  ncor=cor[tn==0,tn==0] 
  
    # rmove genes with all 0 read counts
  rsum=rowSums(raw0)
  rawn0=raw0[rsum!=0,]
  att=round(rawn0[,tn==1])
  acc=round(rawn0[,tn==0])
  csum=colSums(rawn0)
  mcsum=median(csum)
  
  ntt=norm.tumor(att, tcor, ev.thres)
  nttt=apply(ntt, 1, median)
  
  if (missing(both.tumor)) {both.tumor="both"}
  if (both.tumor%in% c("both", "BOTH", "Both"))
  {ncc=norm.tumor(acc, ncor, ev.thres, kcut=2) 
  nccc=apply(ncc, 1, median)
  nninc=(nccc>(inc.thres/2))&(nttt>(inc.thres/2))} else
    
  {ncc=norm.ck(acc, mcsum)
  nccc=apply(ncc, 1, median)
  nninc=nccc>inc.thres}
 
  nadj.NT=cf.fun(nttt, nccc, nninc)
  
  ntt=ntt*(sum(nccc[nadj.NT])/sum(nttt[nadj.NT]))
  ntt=round(ntt)
  
  DFnorm=Norm=data.frame(ncc,ntt)
  
  rtn=c(rep(0, dim(ncc)[[2]]), rep(1, dim(ntt)[[2]]))
  rturn=list(rtn, DFnorm)
  names(rturn)=c("tn", "DFnorm")
  return(rturn)
}
