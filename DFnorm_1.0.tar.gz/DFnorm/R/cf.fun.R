cf.fun <-
function (x, c.t, inc)
{ru1=runif(length(x))[inc]
ru2=runif(length(c.t))[inc]
xb=(x[inc]+ru1)/(x[inc]+c.t[inc]+ru1+ru2)
bk=200
hh=hist(xb, bk, plot=FALSE)
hx=hh[[1]][-1]+(diff(hh[[1]])[1])/2
hy=hh[[2]]

spl=smooth.spline(hx, hy, spar=.7)
hist(xb[inc], bk, plot=FALSE)
points(spl, col=2, type="l")
 predx=seq(0, 1, .01)
predy=predict(spl, predx)
lines(predy$x, predy$y, col=3, lwd=3)
mode=predy$x[predy$x>.1][which(predy$y[predy$x>.1]==max(predy$y[predy$x>.1]))]
#mode=mode(xb, weight=log2(1+x[inc]))
abline(v=(mode), col=2)
rang=.8
molow=mode*rang
moup=1-rang*(1-mode)
inc[inc==TRUE]=xb>molow&xb<moup
return(inc)
}
