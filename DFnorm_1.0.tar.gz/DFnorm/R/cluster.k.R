cluster.k <-
function(cdata,ev.thres){
    ddata <- dist(cdata)
    hclust <- hclust(ddata)
    css <- css.hclust(ddata,hclust)
    elbow <- elbow.batch(css, ev.thres=ev.thres)
    k <- elbow$k
    return(k)
  }
