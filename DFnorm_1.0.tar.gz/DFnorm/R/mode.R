mode <-
function(x, weigh) 
{
  d <- density(x, from=.1, to=.9, n=11111, weight=weigh)
  d$x[which.max(d$y)]
}
