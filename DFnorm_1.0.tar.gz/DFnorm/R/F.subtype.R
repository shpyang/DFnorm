F.subtype <-
function (tcor, kcut)
{ d <- dist(tcor, method = "euclidean") # distance matrix
  fit <- hclust(d, method="ward.D")
  plot(fit)
  groups <- cutree(fit, k=kcut)
  rect.hclust(fit, k=kcut, border="red") 
  countg=table(groups,substr(names(groups),14,14))
  selec.wh=as.numeric(row.names(countg)[which(countg==max(countg))])[1]
  selec.tumor=names(groups)[groups==selec.wh]
  return(selec.tumor)
}
