main.subtype <-
function(tcor, ev.thres, kcut)
{if (missing(ev.thres)) {ev.thres=.1}
 if (missing(kcut)) 
 {kcut=cluster.k(tcor, ev.thres)}
 selec.tumor0=F.subtype(tcor, kcut)
 return(selec.tumor0)
 }
